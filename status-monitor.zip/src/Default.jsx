import * as PIXI from 'pixi.js';
import { useRef, useEffect } from 'react';

import { init } from './statusMonitor';

// const renderer = PIXI.autoDetectRenderer();
const App = () => {
  const ref = useRef(null);

  useEffect(() => {
    const app = new PIXI.Application({ resizeTo: window });
    ref.current.appendChild(app.view);
    init(ref.current, app);
  }, []);

  return <div ref={ref} className="container" />;
};

export default App;
