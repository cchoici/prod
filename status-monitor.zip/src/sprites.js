import * as PIXI from "pixi.js";

export const spriteCircle = (tint, x = 0, y = 0, radius = 20) => {
  const c = new PIXI.Graphics();
  c.beginFill(tint);
  c.drawCircle(x, y, radius);
  c.endFill();

  return c;
};
