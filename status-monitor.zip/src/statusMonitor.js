import * as PIXI from 'pixi.js';
import * as R from 'ramda';

import { MapStatus } from './settings';
import { spriteCircle } from './sprites';

const LANE_HEIGHT = 20;
const SYMBOL_SIZE = 8;
const LANES = 28;
let LANE_STATUS = 100;
const SPEED = 0.8;
const lanes = [];
const laneContainer = new PIXI.Container();
const slots = Array.from(MapStatus.keys(), key =>
  spriteCircle(MapStatus.get(key).color),
);
let _app = null;
let WH = [100, 500];

// const ticker = PIXI.Ticker.shared;
// ticker.autoStart = false;

const setFrame = target => {
  if (!window.ResizeObserver) return console.log('Not support ResizeObserver');

  const resizeObserver = new ResizeObserver(entries => {
    const w = entries?.[0].target?.clientWidth;
    WH[0] = w;
    LANE_STATUS = Math.ceil(w / 8);
  });

  resizeObserver.observe(target);
};

const genSymbol = s => {
  let symbol = s ?? null;
  const graphic = slots[Math.floor(Math.random() * slots.length)];
  // const graphic = slots[Math.floor(i % 4)];
  const renderTexture = _app.renderer.generateTexture(graphic);
  if (symbol) {
    symbol.texture = renderTexture;
  } else {
    symbol = new PIXI.Sprite(renderTexture);
  }
  // Scale the symbol to fit symbol area.
  symbol.scale.x = symbol.scale.y = Math.min(
    SYMBOL_SIZE / symbol.texture.width,
    SYMBOL_SIZE / symbol.texture.height,
  );
  return symbol;
};

const onAssetsLoaded = () => {
  // Build the lanes
  for (let i = 0; i < LANES; i++) {
    const rc = new PIXI.Container();
    rc.position.y = i * LANE_HEIGHT + SYMBOL_SIZE * 2;
    laneContainer.addChild(rc);

    const lane = {
      container: rc,
      symbols: [],
      position: 0,
      previousPosition: 0,
    };

    // Build the symbols
    for (let j = 0; j < LANE_STATUS; j++) {
      const symbol = genSymbol();
      symbol.x = j * SYMBOL_SIZE;
      // symbol.anchor.set(0.5);
      lane.symbols.push(symbol);
      rc.addChild(symbol);
    }
    lanes.push(lane);
  }

  _app.stage.addChild(laneContainer);

  // Listen for animate update.
  _app.ticker.add(() => {
    // Update the slots.
    for (let i = 0; i < lanes.length; i++) {
      const r = lanes[i];
      // Update symbol positions on lane.
      for (let j = 0; j < r.symbols.length; j++) {
        let s = r.symbols[j];

        // s.x = ((r.position + j) % r.symbols.length) * SYMBOL_SIZE - SYMBOL_SIZE;
        s.x -= SPEED;

        if (s.x + SYMBOL_SIZE < 0) {
          // Detect going over and swap a texture.
          // This should in proper product be determined from some logical lane.
          s = genSymbol(s);
          s.x = SYMBOL_SIZE * (r.symbols.length - 1);
        }
      }
    }
  });
};

export const init = (target, app) => {
  _app = app;
  setFrame(target);

  PIXI.Assets.load(`${import.meta.env.BASE_URL}texture.jpg`).then(texture => {
    const tilingSprite = new PIXI.TilingSprite(texture, ...WH);
    _app.stage.addChild(tilingSprite);
    _app.ticker.add(() => {
      tilingSprite.width = R.nth(0, WH);
      tilingSprite.tilePosition.x -= SPEED - 0.1;
    });

    onAssetsLoaded();
  });
};
