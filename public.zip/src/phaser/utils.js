// export const getAsset = fileName => {
//   return new URL(`./appMonitor/${fileName}`, import.meta.url).href;
// };

export const getPublic = fileName => {
  return `${import.meta.env.BASE_URL}appMonitor/${fileName}`;
};
