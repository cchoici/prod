import Phaser from 'phaser';
import { useRef, useEffect } from 'react';

import AppMonitor from './phaser/AppMonitor';

const Default = () => {
  const ref = useRef(null);

  useEffect(() => {
    const config = {
      type: Phaser.AUTO,
      parent: 'appMonitor',
      width: 800,
      height: 600,
      scene: AppMonitor,
    };
    new Phaser.Game(config);
  }, []);
  return <div ref={ref} id="appMonitor" />;
};

export default Default;
